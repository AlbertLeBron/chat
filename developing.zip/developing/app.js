const express = require('express');
const path = require('path');
//const https = require('https');
const fs = require('fs');
const app = express();
//使用静态资源访问,public为根目录
app.use(express.static(path.join(__dirname, '')))
 
app.listen(8869, () => {
  console.log(`App listening at port 8869`)
});

// 读取 SSL/TLS 证书
//const options = {
    //key: fs.readFileSync('server.key'),
    //cert: fs.readFileSync('server.cert')
//};

// 创建 HTTPS 服务器
//https.createServer(options, app).listen(8868, () => {
    //console.log('Video App listening at port 8868');
//});